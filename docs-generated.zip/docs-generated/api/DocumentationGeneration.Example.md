# <a id="DocumentationGeneration_Example"></a> Namespace DocumentationGeneration.Example

### Classes

 [DocumentationExample](DocumentationGeneration.Example.DocumentationExample.md)

Small Unity component used to prove that standard C# XML comments
can become generated API documentation automatically.

